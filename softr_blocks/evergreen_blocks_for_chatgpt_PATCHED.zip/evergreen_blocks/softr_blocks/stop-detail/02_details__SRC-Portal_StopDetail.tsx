import { useMemo, type CSSProperties } from "react";
import { useCurrentUser } from "@/lib/user";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ClipboardList, Clock, Phone, User as UserIcon } from "lucide-react";

function toText(v: any) {
  return v === undefined || v === null ? "" : String(v);
}
function truthy(v: any) {
  const s = toText(v).trim().toLowerCase();
  return s === "true" || s === "yes" || s === "1" || s === "y";
}
function pick(obj: any, keys: string[]) {
  for (const k of keys) {
    const v =
      obj?.[k] ??
      obj?.fields?.[k] ??
      obj?.attributes?.[k] ??
      obj?.record?.[k] ??
      obj?.record?.fields?.[k];
    if (v !== undefined && v !== null && String(v).trim() !== "") return v;
  }
  return "";
}

export default function Block(props: any) {
  const user = useCurrentUser();

  const stops = Array.isArray(props?.stops)
    ? props.stops
    : Array.isArray(props?.records)
    ? props.records
    : Array.isArray(props?.items)
    ? props.items
    : [];

  const params = useMemo(() => {
    const sp = new URLSearchParams(window.location.search);
    return {
      stopId: sp.get("stopId") || sp.get("Stop_ID") || "",
      row: sp.get("row") || "",
      jobsiteId: sp.get("jobsiteId") || "",
    };
  }, []);

  const roleStrings = useMemo(() => {
    const vals = [
      (user as any)?.UserGroup,
      (user as any)?.userGroup,
      (user as any)?.Role,
      (user as any)?.role,
      (user as any)?.Auth_Level,
      (user as any)?.auth_level,
      (user as any)?.fields?.UserGroup,
      (user as any)?.fields?.Role,
      (user as any)?.fields?.Auth_Level,
    ]
      .map(toText)
      .map((x) => x.trim())
      .filter(Boolean);
    return Array.from(new Set(vals));
  }, [user]);

  const isOffice = useMemo(() => {
    const val = roleStrings.join(" ").toLowerCase();
    if (!val) return false;
    return (
      val.includes("office") ||
      val.includes("admin") ||
      val.includes("manager") ||
      val.includes("dispatcher") ||
      val.includes("supervisor") ||
      val.includes("office+")
    );
  }, [roleStrings]);

  const userEmail = useMemo(() => toText((user as any)?.email).toLowerCase(), [user]);

  const normalizeStatus = (raw: any) => {
    const v = toText(raw).toLowerCase();
    if (!v) return "Pending";
    if (v.includes("insufficient") || v.includes("follow") || v.includes("need")) return "Insufficient";
    if (v.includes("reported") || v.includes("complete") || v.includes("done") || v.includes("submitted"))
      return "Reported";
    return "Pending";
  };

  const stop = useMemo(() => {
    if (!stops.length) return null;

    if (params.stopId) {
      const f = stops.find((s: any) => toText(pick(s, ["Stop_ID"])) === params.stopId);
      if (f) return f;
    }
    if (params.row) {
      const f = stops.find((s: any) => toText(pick(s, ["__ROW_NUMBER__", "Row", "Row_Number"])) === params.row);
      if (f) return f;
    }
    if (params.jobsiteId) {
      const f = stops.find((s: any) => toText(pick(s, ["Jobsite_ID", "Site_ID"])) === params.jobsiteId);
      if (f) return f;
    }
    return stops[0] || null;
  }, [stops, params.stopId, params.row, params.jobsiteId]);

  const stopLoginEmail = stop ? toText(pick(stop, ["Login_Email"])).toLowerCase() : "";
  const allowed = !!stop && (isOffice || !stopLoginEmail || !userEmail || stopLoginEmail === userEmail);

  const thinGray: CSSProperties = { color: "rgba(229,231,235,0.55)", fontWeight: 500 };
  const esGray: CSSProperties = { ...thinGray, fontStyle: "italic" };

  const cardStyle: CSSProperties = {
    background:
      "linear-gradient(180deg, rgba(255,255,255,0.045) 0%, rgba(255,255,255,0.028) 100%)",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow: "0 18px 52px rgba(0,0,0,0.40)",
    backdropFilter: "blur(8px)",
  };

  const statusStyle = (st: string): CSSProperties => {
    if (st === "Reported")
      return {
        background: "rgba(16,185,129,0.10)",
        border: "1px solid rgba(16,185,129,0.22)",
        color: "rgba(16,185,129,0.95)",
      };
    if (st === "Insufficient")
      return {
        background: "rgba(239,68,68,0.10)",
        border: "1px solid rgba(239,68,68,0.22)",
        color: "rgba(239,68,68,0.95)",
      };
    return {
      background: "rgba(251,191,36,0.10)",
      border: "1px solid rgba(251,191,36,0.22)",
      color: "rgba(251,191,36,0.95)",
    };
  };

  if (!user) return null;

  if (!stop || !allowed) {
    return (
      <div className="mx-auto w-full max-w-5xl px-4 sm:px-6" style={{ paddingTop: 12, paddingBottom: 12, color: "#E5E7EB" }}>
        <Card className="rounded-2xl" style={cardStyle}>
          <CardContent className="py-8 text-sm" style={{ color: "rgba(229,231,235,0.78)" }}>
            Stop details are not available.
          </CardContent>
        </Card>
      </div>
    );
  }

  const status = normalizeStatus(pick(stop, ["Status", "Report_Status"]));
  const crew = toText(pick(stop, ["Crew_Name", "Crew", "Team", "Crew_ID"]));
  const manifest = toText(pick(stop, ["Manifest_Date", "Manifest_Date_Local", "Stop_Date", "Date", "Day"]));
  const time = toText(pick(stop, ["Scheduled_Time_Local", "Scheduled_Time", "ETA", "Time"]));

  const instructions = toText(
    pick(stop, [
      "Task_Instructions",
      "Instructions",
      "Stop_Instructions",
      "Stop_Title",
      "Task",
      "Work_Notes",
      "Notes",
      "Summary",
    ])
  );

  const access = toText(
    pick(stop, [
      "Access_Notes",
      "Gate_Code",
      "Entry_Code",
      "Lockbox",
      "Parking_Notes",
      "Access",
      "Directions",
    ])
  );

  const contactName = toText(
    pick(stop, ["Contact_Name", "Superintendent", "Foreman", "PM_Name", "Contact", "Onsite_Contact"])
  );
  const contactPhone = toText(pick(stop, ["Contact_Phone", "PM_Phone", "Phone", "Onsite_Phone"]));

  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-6" style={{ paddingTop: 12, paddingBottom: 12, color: "#E5E7EB" }}>
      <Card className="rounded-2xl" style={cardStyle}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <ClipboardList className="w-5 h-5" style={{ color: "rgba(0,233,239,0.95)" }} />
                <span className="truncate">
                  Details <span style={thinGray}>|</span> <span style={esGray}>detalles</span>
                </span>
              </CardTitle>
              <div className="text-xs mt-1" style={thinGray}>
                Stop context (instructions, access, contact).
              </div>
            </div>

            <span className="px-3 py-1 rounded-full text-xs font-semibold" style={statusStyle(status)}>
              {status}
            </span>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <div className="divide-y" style={{ borderTop: "1px solid rgba(255,255,255,0.10)" }}>
            {/* Crew / date / time */}
            <div className="px-4 py-3 grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="text-xs" style={thinGray}>
                Crew
                <div className="text-sm font-semibold text-white mt-1 truncate">{crew || "—"}</div>
              </div>
              <div className="text-xs" style={thinGray}>
                Date
                <div className="text-sm font-semibold text-white mt-1 truncate">{manifest || "—"}</div>
              </div>
              <div className="text-xs" style={thinGray}>
                Time
                <div className="text-sm font-semibold text-white mt-1 truncate inline-flex items-center gap-2">
                  <Clock className="w-4 h-4" style={{ color: "rgba(229,231,235,0.70)" }} />
                  {time || "—"}
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="px-4 py-3">
              <div className="text-xs uppercase tracking-[0.18em]" style={thinGray}>
                Instructions <span style={thinGray}>|</span> <span style={esGray}>instrucciones</span>
              </div>
              <div className="text-sm mt-2 whitespace-pre-line" style={{ color: "rgba(229,231,235,0.88)" }}>
                {instructions || "—"}
              </div>
            </div>

            {/* Access */}
            <div className="px-4 py-3">
              <div className="text-xs uppercase tracking-[0.18em]" style={thinGray}>
                Access <span style={thinGray}>|</span> <span style={esGray}>acceso</span>
              </div>
              <div className="text-sm mt-2 whitespace-pre-line" style={{ color: "rgba(229,231,235,0.88)" }}>
                {access || "—"}
              </div>
            </div>

            {/* Contact */}
            <div className="px-4 py-3">
              <div className="text-xs uppercase tracking-[0.18em]" style={thinGray}>
                Contact <span style={thinGray}>|</span> <span style={esGray}>contacto</span>
              </div>

              <div className="mt-2 space-y-2">
                <div className="flex items-center gap-2 text-sm" style={{ color: "rgba(229,231,235,0.88)" }}>
                  <UserIcon className="w-4 h-4" style={{ color: "rgba(229,231,235,0.70)" }} />
                  <span className="font-semibold text-white">{contactName || "—"}</span>
                </div>

                {contactPhone ? (
                  <a
                    href={`tel:${contactPhone}`}
                    className="inline-flex items-center gap-2 text-sm font-semibold"
                    style={{ color: "rgba(0,233,239,0.96)" }}
                  >
                    <Phone className="w-4 h-4" />
                    {contactPhone}
                  </a>
                ) : (
                  <div className="text-sm" style={{ color: "rgba(229,231,235,0.78)" }}>
                    Phone: —
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
