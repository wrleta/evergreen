import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { useCurrentUser } from "@/lib/user";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, ChevronRight, Info } from "lucide-react";

type HomeState = { q: string; showStops: boolean; showBulletins: boolean };
const HOME_STATE_KEY = "__RK_HOME_STATE__";
const HOME_EVENT = "rk-home-state";

function toText(v: any) {
  return v === undefined || v === null ? "" : String(v);
}
function truthy(v: any) {
  const s = toText(v).trim().toLowerCase();
  return s === "true" || s === "yes" || s === "1" || s === "y";
}
function pick(obj: any, keys: string[]) {
  for (const k of keys) {
    const v =
      obj?.[k] ??
      obj?.fields?.[k] ??
      obj?.attributes?.[k] ??
      obj?.record?.[k] ??
      obj?.record?.fields?.[k];
    if (v !== undefined && v !== null && String(v).trim() !== "") return v;
  }
  return "";
}

function getHomeState(): HomeState {
  const w = window as any;
  const cur = (w?.[HOME_STATE_KEY] ?? {}) as Partial<HomeState>;
  return {
    q: toText(cur.q ?? ""),
    showStops: cur.showStops ?? true,
    showBulletins: cur.showBulletins ?? true,
  };
}

export default function Block(props: any) {
  const user = useCurrentUser();

  const bulletins = Array.isArray(props?.bulletins)
    ? props.bulletins
    : Array.isArray(props?.records)
    ? props.records
    : Array.isArray(props?.items)
    ? props.items
    : [];

  const routes = {
    bulletins: "/bulletins",
    faq: "/faq",
  };
  const nav = (href: string) => (window.location.href = href);

  const [home, setHome] = useState<HomeState>(() =>
    typeof window !== "undefined" ? getHomeState() : { q: "", showStops: true, showBulletins: true }
  );

  useEffect(() => {
    const onState = (ev: any) => setHome((ev?.detail as HomeState) || getHomeState());
    window.addEventListener(HOME_EVENT, onState as any);
    // hydrate once in case this block loaded before header
    setHome(getHomeState());
    return () => window.removeEventListener(HOME_EVENT, onState as any);
  }, []);

  const normalizeRead = (b: any) => {
    const v = toText(
      pick(b, ["Is_Read", "Read", "Read_Status", "Bulletin_Read", "Has_Read", "Read_Flag"])
    )
      .toLowerCase()
      .trim();
    if (!v) return false;
    if (v === "true" || v === "yes" || v === "1" || v === "read") return true;
    if (v.includes("read")) return true;
    return false;
  };

  const getDateMs = (b: any) => {
    const d = pick(b, [
      "Published_At_Local",
      "Updated_At_Local",
      "Created_At_Local",
      "Start_At_Local",
      "Posted_At",
      "Created_At",
      "Date",
      "Timestamp",
    ]);
    const t = Date.parse(toText(d));
    return Number.isFinite(t) ? t : 0;
  };

  const isPinned = (b: any) =>
    truthy(pick(b, ["Is_Pinned", "Pinned", "Pin", "Pinned_Flag", "Top_Pinned", "Show_On_Home"]));
  const getPriority = (b: any) => {
    const raw = pick(b, ["Priority", "Sort_Priority", "Urgency", "Rank"]);
    const n = Number(raw);
    return Number.isFinite(n) ? n : 0;
  };

  const sorted = useMemo(() => {
    const arr = Array.isArray(bulletins) ? [...bulletins] : [];
    arr.sort((a, b) => {
      const pin = Number(isPinned(b)) - Number(isPinned(a));
      if (pin !== 0) return pin;
      const pr = getPriority(b) - getPriority(a);
      if (pr !== 0) return pr;
      return getDateMs(b) - getDateMs(a);
    });
    return arr;
  }, [bulletins]);

  const counts = useMemo(() => {
    let unread = 0;
    for (const b of sorted) if (!normalizeRead(b)) unread++;
    return { total: sorted.length, unread };
  }, [sorted]);

  const filtered = useMemo(() => {
    if (!home.showBulletins) return [];
    const qq = home.q.trim().toLowerCase();
    if (!qq) return sorted;

    return sorted.filter((b: any) => {
      const title = toText(pick(b, ["Title", "Title_EN", "Title_ES", "Bulletin_Title", "Subject", "Name"]));
      const body = toText(pick(b, ["Body", "Body_EN", "Body_ES", "Message", "Details", "Summary"]));
      const when = toText(
        pick(b, [
          "Published_At_Local",
          "Updated_At_Local",
          "Created_At_Local",
          "Start_At_Local",
          "Posted_At",
          "Created_At",
          "Date",
          "Timestamp",
        ])
      );
      const hay = `${title} ${body} ${when}`.toLowerCase();
      return hay.includes(qq);
    });
  }, [sorted, home.showBulletins, home.q]);

  const preview = useMemo(() => filtered.slice(0, 3), [filtered]);

  const openDetail = (b: any) => {
    const id = toText(pick(b, ["id", "ID", "Bulletin_ID", "__ROW_NUMBER__"]));
    if (id) return nav(`${routes.bulletins}?id=${encodeURIComponent(id)}`);

    const title = toText(pick(b, ["Title", "Title_EN", "Title_ES", "Bulletin_Title", "Subject", "Name"]));
    const when = toText(
      pick(b, [
        "Published_At_Local",
        "Updated_At_Local",
        "Created_At_Local",
        "Start_At_Local",
        "Posted_At",
        "Created_At",
        "Date",
        "Timestamp",
      ])
    );
    nav(`${routes.bulletins}?title=${encodeURIComponent(title)}&date=${encodeURIComponent(when)}`);
  };

  const thinGray: CSSProperties = { color: "rgba(229,231,235,0.55)", fontWeight: 500 };
  const esGray: CSSProperties = { ...thinGray, fontStyle: "italic" };

  const cardStyle: CSSProperties = {
    background:
      "linear-gradient(180deg, rgba(255,255,255,0.045) 0%, rgba(255,255,255,0.028) 100%)",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow: "0 18px 52px rgba(0,0,0,0.40)",
    backdropFilter: "blur(8px)",
  };

  const rowBtn: CSSProperties = {
    width: "100%",
    textAlign: "left",
    background: "transparent",
    border: "none",
    padding: 0,
    cursor: "pointer",
  };

  const unreadPill: CSSProperties = {
    background: "rgba(251,191,36,0.12)",
    border: "1px solid rgba(251,191,36,0.24)",
    color: "rgba(251,191,36,0.95)",
  };

  if (!user) return null;

  return (
    <div className="mx-auto w-full max-w-5xl px-4 sm:px-6" style={{ paddingTop: 12, paddingBottom: 12, color: "#E5E7EB" }}>
      <Card className="rounded-2xl" style={cardStyle}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <Bell className="w-5 h-5" style={{ color: "rgba(0,233,239,0.95)" }} />
                <span className="truncate">
                  Bulletins <span style={thinGray}>|</span> <span style={esGray}>boletines</span>
                </span>
              </CardTitle>
              <div className="text-xs mt-1" style={thinGray}>
                Updates from the office (unread stays highlighted).
              </div>
            </div>

            <Button
              variant="ghost"
              size="sm"
              className="h-8 px-2"
              style={{ color: "rgba(0,233,239,0.95)" }}
              onClick={() => nav(routes.bulletins)}
            >
              View all <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {/* pills */}
          <div className="px-4 pb-3 flex flex-wrap gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-semibold" style={{ background: "rgba(0,233,239,0.12)", border: "1px solid rgba(0,233,239,0.22)", color: "rgba(0,233,239,0.95)" }}>
              Total: {counts.total}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold" style={unreadPill}>
              Unread: {counts.unread}
            </span>

            <button
              onClick={() => nav(routes.faq)}
              style={{
                marginLeft: "auto",
                background: "transparent",
                border: "none",
                padding: 0,
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                color: "rgba(0,233,239,0.96)",
                fontWeight: 800,
                fontSize: 13,
                cursor: "pointer",
                whiteSpace: "nowrap",
              }}
            >
              <Info className="w-4 h-4" />
              FAQ
            </button>
          </div>

          {/* list */}
          {preview.length ? (
            <div className="divide-y" style={{ borderTop: "1px solid rgba(255,255,255,0.10)" }}>
              {preview.map((b: any, idx: number) => {
                const title = toText(
                  pick(b, ["Title", "Title_EN", "Title_ES", "Bulletin_Title", "Subject", "Name"])
                ) || `Bulletin ${idx + 1}`;
                const when = toText(
                  pick(b, ["Published_At_Local", "Updated_At_Local", "Created_At_Local", "Posted_At", "Created_At", "Date"])
                );
                const unread = !normalizeRead(b);

                return (
                  <div key={idx} className="px-4 py-3">
                    <button style={rowBtn} onClick={() => openDetail(b)} aria-label={`Open bulletin: ${title}`}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-white truncate">
                            {title}
                          </div>
                          {when ? (
                            <div className="text-xs mt-1" style={thinGray}>
                              {when}
                            </div>
                          ) : null}
                        </div>
                        {unread ? (
                          <span className="px-3 py-1 rounded-full text-xs font-semibold" style={unreadPill}>
                            Unread
                          </span>
                        ) : null}
                      </div>
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="px-4 py-8 text-sm" style={{ color: "rgba(229,231,235,0.75)" }}>
              {home.showBulletins ? "No bulletins match your search." : "Bulletins are hidden by Filter (toggle on above)."}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
